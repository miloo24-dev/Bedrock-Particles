package com.bedrockparticles.mixin;

import net.minecraft.client.particle.Particle;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(Particle.class)
public interface ParticleAccessor {
	@Accessor("gravity") float bp$getGravity();
	@Accessor("gravity") void bp$setGravity(float v);
	@Accessor("xd") double bp$getXd();
	@Accessor("xd") void bp$setXd(double v);
	@Accessor("yd") double bp$getYd();
	@Accessor("yd") void bp$setYd(double v);
	@Accessor("zd") double bp$getZd();
	@Accessor("zd") void bp$setZd(double v);
}
