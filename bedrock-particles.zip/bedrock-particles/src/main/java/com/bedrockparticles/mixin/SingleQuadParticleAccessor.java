package com.bedrockparticles.mixin;

import net.minecraft.client.particle.SingleQuadParticle;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(SingleQuadParticle.class)
public interface SingleQuadParticleAccessor {
	@Accessor("quadSize") float bp$getQuadSize();
	@Accessor("quadSize") void bp$setQuadSize(float v);
}
