package com.bedrockparticles.mixin;

import net.minecraft.client.particle.SingleQuadParticle;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(SingleQuadParticle.class)
public interface SingleQuadParticleAccessor {
	@Accessor("quadSize") float bp$getQuadSize();
	@Accessor("quadSize") void bp$setQuadSize(float v);
	@Accessor("rCol") float bp$getR();
	@Accessor("rCol") void bp$setR(float v);
	@Accessor("gCol") float bp$getG();
	@Accessor("gCol") void bp$setG(float v);
	@Accessor("bCol") float bp$getB();
	@Accessor("bCol") void bp$setB(float v);
}
