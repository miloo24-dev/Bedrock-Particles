package com.bedrockparticles.mixin;

import net.minecraft.client.particle.TerrainParticle;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Makes Java block particles behave and look more like Bedrock:
 * full brightness, much smaller, heavier gravity (drop straight down fast)
 * and less sideways spread.
 */
@Mixin(TerrainParticle.class)
public abstract class TerrainParticleMixin {
	private static final float VANILLA_DARKEN = 0.6F;
	private static final float SIZE_SCALE = 0.5F;      // smaller = tiny Bedrock chips
	private static final float GRAVITY_SCALE = 1.9F;   // higher = falls faster
	private static final double SPREAD_SCALE = 0.55;   // sideways speed
	private static final double UP_SCALE = 0.6;        // upward kick

	@Inject(method = "<init>", at = @At("RETURN"))
	private void bedrockparticles$bedrockify(CallbackInfo ci) {
		ParticleAccessor p = (ParticleAccessor) (Object) this;
		p.bp$setR(Math.min(1.0F, p.bp$getR() / VANILLA_DARKEN));
		p.bp$setG(Math.min(1.0F, p.bp$getG() / VANILLA_DARKEN));
		p.bp$setB(Math.min(1.0F, p.bp$getB() / VANILLA_DARKEN));

		p.bp$setGravity(p.bp$getGravity() * GRAVITY_SCALE);
		p.bp$setXd(p.bp$getXd() * SPREAD_SCALE);
		p.bp$setZd(p.bp$getZd() * SPREAD_SCALE);
		p.bp$setYd(p.bp$getYd() * UP_SCALE);

		SingleQuadParticleAccessor q = (SingleQuadParticleAccessor) (Object) this;
		q.bp$setQuadSize(q.bp$getQuadSize() * SIZE_SCALE);
	}
}
