# Bedrock Particles
Fabric client mod for Minecraft 26.3 (Fabric Loader 0.20.1+, Java 25). No Fabric API needed.
Block break particles are shown at full brightness and slightly smaller, like Bedrock Edition.
Tweak VANILLA_DARKEN / SIZE_SCALE in TerrainParticleMixin.java.
